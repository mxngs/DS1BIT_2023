package br.senai.sp.jandira;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
	
	
	public class CalculoIMC extends JFrame implements ActionListener{
	
	JLabel lblPeso = new JLabel("Peso: ");
	JLabel lblAltura = new JLabel("Altura: ");
	JTextField txtPeso = new JTextField();
	JTextField txtAltura = new JTextField();			
	
	JButton btnCalcular = new JButton("Calcular IMC");
	JButton btnSair = new JButton("Sair");
	
	public CalculoIMC() {
		
		btnCalcular.addActionListener(this);
		btnSair.addA'ctionListener(this);
		
		setLayout(null);
		btnCalcular.setBounds(50, 300, 120, 30);
		btnSair.setBounds(200, 300, 110, 30);
		btnSair.setBounds(340, 300, 100, 30);
		add(btnCalcular);
		add(btnSair);
		
		lblPeso.setBounds(155, 102 , 100, 20);
		lblAltura.setBounds(155, 152, 110, 20);
		add(lblPeso);
		add(lblAltura);
		
		txtPeso.setBounds(200, 100, 100, 30);
		txtAltura.setBounds(200, 150, 100, 30);
		add(txtPeso);
		add(txtAltura);		
		
		setTitle("C�lculo do IMC");
		setSize(500, 400);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);		
		
	}
	
	public static void main(String[] args) {
		new CalculoIMC();}
	
	public void actionPerformed(ActionEvent evento) {
			
			if(evento.getSource() == btnCalcular) {
				if(!txtPeso.getText().equals("")) {
					
					String Peso = txtPeso.getText();
					String Altura = txtAltura.getText();
					double Peso1 = Double.parseDouble(Peso);
					double Altura1 = Double.parseDouble(Altura);
					double imc = Peso1 / (Altura1 * Altura1);
					
					String texto = "Seu IMC �: " +  imc  ; 

					 
					JOptionPane.showMessageDialog(null, texto);
					
				}
			}

			if(evento.getSource() == btnSair) {
				System.exit(0);
			}
		}	
	}
